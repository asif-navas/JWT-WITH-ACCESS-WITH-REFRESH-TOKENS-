import React, { useState } from 'react';
import './SignUp.css';
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';

function SignUp() {

  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const navigate = useNavigate();

//Authtentication
  axios.defaults.withCredentials = true;

  const handleLogin =async (event) => {
    event.preventDefault();
    try{
      await axios.post('http://localhost:3001/login',{email,password})
      .then(Response =>{
        alert(Response.data.message)
        // console.log(Response)

        if(Response.data.Login){

          navigate('/')
        }else{
          navigate('/login');
        }

      } )
    }catch (err){
      console.log("err is "+err);
    }
    
  };

  return (
    <div >
      <h2>Log In</h2>

      <form onSubmit={handleLogin}>
      
        {/* Email */}
        <label htmlFor="email">Email:</label>
        <input type="email" id="email" name="email" placeholder='Enter Name' onChange={(e) => setEmail(e.target.value)} required />

        {/* Password */}
        <label htmlFor="password">Password:</label>
        <input type="password" id="password" name="password" placeholder='Enter Password' onChange={(e) => setPassword (e.target.value)} required />

        <Link  to="/signUp">Don't Have an account ?</Link>

        {/* Submit Button */}
        <input type="submit" value="Login" />
      </form>
    </div>
  );
}

export default SignUp;
