const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const UserModel = require('./model/UserModel');

//Authentication
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
//----------------------------------------

const app = express();

// middleware

//auth
app.use(cors({
    origin: ['http://localhost:5173'],
    methods: ['GET', 'POST'],
    credentials: true
}));


//_________________
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(cookieParser());

// mongoDB connection

mongoose.connect("mongodb://localhost:27017/JWT-APP-1")
const db=mongoose.connection;
db.on('error',console.error.bind(console,"conection error"));
db.once('open',function(){
    console.log(" Mongo DB Connected sucessfully")
});





//Verify User(middleware)

const VerifyUser = (req, res, next) =>{
    const accesstoken = req.cookies.accesstoken;
    

    // console.log(token);

    if(!accesstoken){
       if (renewToken(req, res)){
            next()
       }
    }else{
        jwt.verify(accesstoken,"jwt-access-token-secret-key", (err,decoded) =>{
            if(err) {
                return res.json( {valid : false , message:"Invalid Access Token" });
            }else{
                // return res.json(decoded);
                // req.email = decoded.email;
                next();
            }
        })
    }
}


//Function For Renew Token
const renewToken = ( req, res )=>{
    const refreshtoken = req.cookies.refreshtoken;

    let exist = false;

    if(!refreshtoken){
        return res.json({ valid: false, message: "The Refresh Token was not Available"});
    }else{
        jwt.verify(refreshtoken,"jwt-refresh-token-secret-key", (err,decoded) =>{
            if(err) {
                return res.json( {valid : false , message:"Invalid Refresh Token" });
            }else{
               // Generating an access token with a 60-second expiration
               const accesstoken = jwt.sign({email: decoded.email},"jwt-access-token-secret-key", {expiresIn:60})
               res.cookie('accesstoken',accesstoken, {maxAge:60000});
               exist=true;
            }

            
        })
    }
    return exist;
}





//Register User
app.post('/register',(req,res) => {
    const {name,email,password} = req.body;

    bcrypt.hash(password, 10)

    .then(hash => {
         UserModel.create({name,email, password: hash})
        .then(result => res.json(result))
        .catch(err => res.json(err))
    }).catch(err => console.log(err))


})



//Home 


app.get('/details', VerifyUser, async (req, res) => {
    try {
        // Authorization check
        const fetchdata = await UserModel.find();
        res.json({ valid: true, message: "Authorized", fetchdata });
    } catch (err) {
        console.error(err);
    }
});


//Login User

app.post('/login',(req,res) => {
    const {email,password} = req.body;
    try {
        UserModel.findOne({email: email})

        .then((user)=>{
            if(user) {

                   //password compare

                bcrypt.compare(password,user.password, (err,response) => {
                    if(err) {
                        console.log ("Compare error"+err);
                    }
                    // console.log(err)
                    if(response){

                        //generate Access Token & Refresh Token------------------

                        // Generating an access token with a 60-second expiration
                        const accesstoken = jwt.sign({email: user.email},
                             "jwt-access-token-secret-key", {expiresIn:60})


                        // Generating a refresh token with a 300-second (5 minutes) expiration
                        const refreshtoken = jwt.sign({email: user.email},
                                "jwt-refresh-token-secret-key", {expiresIn:300})

                        // storing the tokens in the cookie
                        res.cookie('accesstoken',accesstoken, {maxAge:60000});
                        res.cookie('refreshtoken',refreshtoken, {maxAge:300000, httpOnly:true, secure: true, sameSite: 'strict'});

                        return res.json({Login : true , message : 'Login successful'});
                        
                    }else{
                        res.json({message : 'Password is incorrect'});
                    }
                })

            }else {
                return res.json({Login: false, message: "No records found"});
            }
        })
        
    } catch(err){
        console.log("Login err is " + err)
    }
})

app.listen(3001,() => 
console.log("port is running port = 3001")
);